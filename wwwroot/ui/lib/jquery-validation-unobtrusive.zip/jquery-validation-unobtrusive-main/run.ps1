dotnet build .\build.proj $args
