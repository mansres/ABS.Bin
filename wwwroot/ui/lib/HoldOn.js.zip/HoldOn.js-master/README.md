# HoldOn.js
Prevent that your user do something stupid when you need to. Lock the ui with 1 line of code.
#Demo
[Official Demo](https://sdkcarlos.github.io/sites/holdon.html)
#Documentation
[Official documentation](http://docs.ourcodeworld.com/projects/holdon-js)
